from django.contrib import admin
from .models import Regadmin
admin.site.register(Regadmin)

# Register your models here.
